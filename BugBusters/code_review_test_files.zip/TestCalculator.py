class TestCalculator:

    # ✅ Đúng: Cộng hai số
    def add(self, a, b):
        return a + b

    # ✅ Đúng: Trừ hai số
    def subtract(self, a, b):
        return a - b

    # ❌ Sai cú pháp: Nhân hai số (thiếu dấu ":" và lỗi indentation)
    def multiply(self, a, b)
        result = a * b
        return result

    # ❌ Sai logic: Chia hai số (ngược logic, không xử lý chia cho 0)
    def divide(self, a, b):
        return a * b
