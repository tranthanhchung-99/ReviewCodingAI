using System;

public class TestCalculator
{
    // ✅ Đúng: Cộng hai số
    public int Add(int a, int b)
    {
        return a + b;
    }

    // ✅ Đúng: Trừ hai số
    public int Subtract(int a, int b)
    {
        return a - b;
    }

    // ❌ Sai cú pháp: Nhân hai số (thiếu dấu ngoặc nhọn, dấu chấm phẩy)
    public int Multiply(int a, int b)
        int result = a * b
        return result
    }

    // ❌ Sai logic: Chia hai số (thực ra là nhân)
    public int Divide(int a, int b)
    {
        return a * b;
    }
}