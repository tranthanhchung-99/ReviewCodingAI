public class TestCalculator {

    // ✅ Đúng: Cộng hai số
    public static int add(int a, int b) {
        return a + b;
    }

    // ✅ Đúng: Trừ hai số
    public static int subtract(int a, int b) {
        return a - b;
    }

    // ❌ Sai cú pháp: Nhân hai số (thiếu dấu chấm phẩy và lỗi cú pháp)
    public static int multiply(int a, int b)
        int result = a * b
        return result
    }

    // ❌ Sai logic: Chia hai số (logic ngược, và chia cho 0 mà không kiểm tra)
    public static int divide(int a, int b) {
        return a * b;
    }
}